This data comes from the Natural Earth Data website at http://www.naturalearthdata.com, downloaded on July 1, 2011.

ocean: 110m-ocean
cities: 110m-populated-places-simple
countries: 50m-admin-0-countries
shadedrelief: NE1_50M_SR (manually downsampled to 72 dpi using gdalwarp)